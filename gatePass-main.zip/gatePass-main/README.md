# gatePass
 Developed an application for gate pass issue mechanism at CBIT
 
 ![image](https://user-images.githubusercontent.com/92909904/173243833-21173ca4-e82f-43a6-a918-f28060d63288.png)
 ![image](https://user-images.githubusercontent.com/92909904/173243873-8e3362e8-b089-4dd5-8214-19d754ce4ef0.png)
 ![image](https://user-images.githubusercontent.com/92909904/173243889-7c690038-011e-4156-a2d8-bab3411d2e6b.png)
![image](https://user-images.githubusercontent.com/92909904/173243896-e1246eaa-6e25-4202-90b3-09fd1960fb67.png)
![image](https://user-images.githubusercontent.com/92909904/173243958-8c221a2d-b6ff-460c-9785-c1081dc1dd11.png)



